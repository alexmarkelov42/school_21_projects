# 0.6.1 (2021-12-21)

- fixed `--protocol` option when used in `--protocol http` form - [#17](https://github.com/westandskif/rate-mirrors/pull/17)

# 0.6.0 (2021-11-21)

- added ArtixLinux support
- added clear error messages

# 0.5.1 (2021-09-22)

- fixed dead code warning - [#9](https://github.com/westandskif/rate-mirrors/issues/9)
- brought package version up to date with the tag - [#10](https://github.com/westandskif/rate-mirrors/issues/10)

# 0.5.0 (2021-07-15)

- Added RebornOS support

# 0.4.0 (2021-06-24) -- BREAKING CHANGES

- **! BREAKING CHANGE !** now the tool is named "rate mirrors"
- **! BREAKING CHANGE !** now there are three sub-commands for three different modes:

  - arch
  - manjaro
  - stdin

  See the readme for details.

  Configuration options are also split into common ones (which go before
  sub-command) and mode-specific ones (which go after)

- Added `--allow-root` option to run as root

# 0.3.0 (2021-05-20)

- Added `--save` option to write output to file
- Now it fails when run as root

# 0.2.1 (2021-02-22)

- Enabled _vendored_ feature for `openssl-sys` crate to allow for musl builds

# 0.2.0 (2021-02-21)

- Added `--sort-mirrors-by` option to control how mirrors are initially sorted
  within the country, `store_asc` by default. The full list of options is:
  _score_asc, score_desc, delay_asc, delay_desc, random_

- Added `--protocol` option to control acceptable protocols `https`, `http`. Both
  both are enabled by default. Rsync not supported.

# 0.1.0 (2021-01-17)

Initial.
