pub mod archlinux;
pub mod manjaro;
pub mod rebornos;
pub mod stdin;
pub mod artix;
